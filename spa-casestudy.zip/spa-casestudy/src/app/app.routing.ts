import { Routes, RouterModule } from '@angular/router';

import {LoginComponent} from './components/Login.component'
import { AlwaysAuthGuard } from './services/AlwaysAuthGuard';
import {ServiceComponent} from './components/service.component'
import {ContactListComponent} from './components/contactlist.component'
import {ShowComponent} from './components/show.component'
import {NewContactComponent} from './components/newcontact.component'
export const customRoutes: Routes = [    
    {path:'',component:LoginComponent,canActivate:[AlwaysAuthGuard]},
    {path:'services',component:ServiceComponent},
    {path:'contacts',component:ContactListComponent},
    {path:'show/:selected',component:ShowComponent},    
    {path: 'newcontact', component: NewContactComponent},

    { path: 'about', loadChildren: './about/about.module#AboutModule'},
    {path: '**', component: LoginComponent} //catch all = **    
];
export const SPArouting = RouterModule.forRoot(customRoutes);